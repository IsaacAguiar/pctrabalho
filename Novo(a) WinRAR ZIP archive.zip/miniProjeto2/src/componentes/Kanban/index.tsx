import { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './kanban.css';
import NewCardComponent from './newcard';
import TodoCard from './todocard';

const API_URL = 'https://arnia-kanban.vercel.app'; 
const API_KEY = '52a8b954-e25d-4cc5-86e5-c32e92f994bb';

interface Card {
    id: number;
    title: string;
    content: string;
    status: 'new' | 'to-do' | 'doing' | 'done';
}

const Kanban = () => {
    const [userName, setUserName] = useState<string | null>(null);
    const [cards, setCards] = useState<Card[]>([]);
    const navigate = useNavigate();

    const fetchCards = useCallback(async () => {
        

        try {
            const response = await axios.get<Card[]>(`${API_URL}/api/card`, {
                headers: {
                    
                    'x-api-key': API_KEY
                }
            });
            setCards(response.data);
        } catch (error) {
            console.error("Error fetching cards:", error);
        }
    }, [navigate]);

    useEffect(() => {
        const name = localStorage.getItem('USER_NAME');
        if (name) {
            setUserName(name);
        }

        fetchCards();
    }, [fetchCards]);

    
    const handleDelete = async (id: number) => {
        try {
            await axios.delete(`${API_URL}/api/card/${id}`, {
                headers: {
                    'Authorization': 'Bearer ' + API_KEY,
                    'x-api-key': API_KEY
                }
            });
            
            setCards(prevCards => prevCards.filter(card => card.id !== id));
            fetchCards();
        } catch (error) {
            console.error('Error deleting card:', error);
        }
    };

    
    const renderCards = (status: 'new' | 'to-do' | 'doing' | 'done') => {
        return cards.filter(card => card.status === status).map(card => (
            <TodoCard 
                key={card.id} 
                id={card.id} 
                title={card.title} 
                content={card.content}
                onEdit={fetchCards}
                onDelete={() => handleDelete(card.id)}
                onMove={fetchCards}
            />
        ));
    };

    return (
        <div className="kanban-container">
            <div className='topo'>
                <div>
                    <h1>Arnia Trello</h1>
                </div>
                <div className='menu'>
                    <div className='ola'>Olá, {userName ? userName : 'Visitante'}</div>
                    <div className='sair'>
                        <Link to="/login">Sair</Link>
                    </div>
                </div>
            </div>

            <div className='containers-bloco'>
                <div className='new containers'>
                    <div className='titulos'>New</div>
                    <NewCardComponent onCardAdded={fetchCards} />
                    {renderCards('new')}
                </div>

                <div className='to-do containers'>
                    <div className='titulos'>To Do</div>
                    {renderCards('to-do')}
                </div>

                <div className='doing containers'>
                    <div className='titulos'>Doing</div>
                    {renderCards('doing')}
                </div>

                <div className='done containers'>
                    <div className='titulos'>Done</div>
                    {renderCards('done')}
                </div>
            </div>
        </div>
    );
}

export default Kanban;  